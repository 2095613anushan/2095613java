
public class VariableDemo {
	
	int a1;           //Instance variable
	static int b1;    // static variable
	  
	
	int RegisterNumber;
	int $age;
	int _height;
	
	int age;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;         //local variable
        System.out.println(a);
        System.out.println(b1);
	}
	void disp() {
		System.out.println(a1+b1);
		
	}

}
