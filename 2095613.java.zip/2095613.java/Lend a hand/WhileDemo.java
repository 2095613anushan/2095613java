package com.cognizant;

public class WhileDemo {

	public static void main(String[] args) throws InterruptedException {
		
		short a= 2212;
		while(true){
			System.out.println("Cognizant:"+a);
			
			a++;
		}
		

	}

}
